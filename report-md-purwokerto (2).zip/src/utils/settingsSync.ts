import { SiteSettings, BannerSlide } from '../types';
import { DEFAULT_BANNERS, DEFAULT_SETTINGS } from '../constants';

const META_DELIMITER = '\u2063__CFG__:';

interface PackedUiMeta {
  we?: boolean;
  wt?: string;
  wl?: string;
  bf?: Array<'contain' | 'cover'>;
}

const parseBooleanFlag = (val: unknown, defaultValue: boolean): boolean => {
  if (typeof val === 'boolean') return val;
  if (typeof val === 'string') {
    const lower = val.trim().toLowerCase();
    if (lower === 'false' || lower === '0' || lower === 'off' || lower === 'tidak') return false;
    if (lower === 'true' || lower === '1' || lower === 'on' || lower === 'ya') return true;
  }
  return defaultValue;
};

/**
 * Strips any packed metadata suffix from searchPlaceholder so UI inputs only ever see clean text.
 */
export const stripSearchPlaceholderMeta = (rawPlaceholder?: string): string => {
  if (!rawPlaceholder) return DEFAULT_SETTINGS.searchPlaceholder;
  const idx = rawPlaceholder.indexOf(META_DELIMITER);
  const clean = idx >= 0 ? rawPlaceholder.slice(0, idx) : rawPlaceholder;
  return clean || DEFAULT_SETTINGS.searchPlaceholder;
};

/**
 * Unpacks settings received from Google Apps Script (both legacy deployments and updated Code.gs)
 * or localStorage, preserving watermarkEnabled, watermarkText, watermarkLink, and banner fitMode.
 */
export const unpackSettingsFromCloud = (
  raw: Record<string, unknown> | Partial<SiteSettings> | undefined | null,
  fallback: SiteSettings = DEFAULT_SETTINGS
): SiteSettings => {
  if (!raw || typeof raw !== 'object') {
    return { ...fallback };
  }

  const record = raw as Record<string, unknown>;

  // Recombine multi-part logo if returned by an older Apps Script deployment
  let resolvedLogoUrl =
    typeof record.logoUrl === 'string' ? record.logoUrl : fallback.logoUrl || '';
  if (typeof record.logoUrl_part2 === 'string' && record.logoUrl_part2) {
    resolvedLogoUrl += record.logoUrl_part2;
  }
  if (typeof record.logoUrl_part3 === 'string' && record.logoUrl_part3) {
    resolvedLogoUrl += record.logoUrl_part3;
  }

  // Extract embedded metadata from searchPlaceholder if present
  const rawPlaceholder =
    typeof record.searchPlaceholder === 'string'
      ? record.searchPlaceholder
      : fallback.searchPlaceholder;

  let cleanPlaceholder = rawPlaceholder || DEFAULT_SETTINGS.searchPlaceholder;
  let packedMeta: PackedUiMeta | null = null;

  const metaIdx = rawPlaceholder.indexOf(META_DELIMITER);
  if (metaIdx >= 0) {
    cleanPlaceholder = rawPlaceholder.slice(0, metaIdx) || DEFAULT_SETTINGS.searchPlaceholder;
    const jsonPart = rawPlaceholder.slice(metaIdx + META_DELIMITER.length);
    try {
      const parsed = JSON.parse(jsonPart);
      if (parsed && typeof parsed === 'object') {
        packedMeta = parsed as PackedUiMeta;
      }
    } catch {
      packedMeta = null;
    }
  }

  // Resolve banners
  const rawBanners = Array.isArray(record.banners) && record.banners.length > 0
    ? (record.banners as BannerSlide[])
    : fallback.banners && fallback.banners.length > 0
    ? fallback.banners
    : DEFAULT_BANNERS;

  const resolvedBanners: BannerSlide[] = rawBanners.map((b, idx) => {
    const packedFit = packedMeta?.bf?.[idx];
    const explicitFit = b.fitMode === 'cover' || b.fitMode === 'contain' ? b.fitMode : undefined;
    return {
      ...b,
      fitMode: explicitFit || packedFit || 'contain',
    };
  });

  // Resolve Watermark settings:
  // Priority 1: Packed metadata stored inside searchPlaceholder (works even on legacy Code.gs deployments)
  // Priority 2: Explicit top-level keys from updated Code.gs / localStorage
  // Priority 3: Current fallback state
  let watermarkEnabled: boolean;
  if (packedMeta && typeof packedMeta.we === 'boolean') {
    watermarkEnabled = packedMeta.we;
  } else if (record.watermarkEnabled !== undefined) {
    watermarkEnabled = parseBooleanFlag(
      record.watermarkEnabled,
      fallback.watermarkEnabled !== false
    );
  } else {
    watermarkEnabled = fallback.watermarkEnabled !== false;
  }

  let watermarkText: string;
  if (packedMeta && typeof packedMeta.wt === 'string') {
    watermarkText = packedMeta.wt;
  } else if (typeof record.watermarkText === 'string') {
    watermarkText = record.watermarkText;
  } else {
    watermarkText = fallback.watermarkText ?? DEFAULT_SETTINGS.watermarkText ?? 'Powered by Intisari';
  }

  let watermarkLink: string;
  if (packedMeta && typeof packedMeta.wl === 'string') {
    watermarkLink = packedMeta.wl;
  } else if (typeof record.watermarkLink === 'string') {
    watermarkLink = record.watermarkLink;
  } else {
    watermarkLink = fallback.watermarkLink ?? '';
  }

  const intervalNum = Number(record.bannerAutoSlideInterval);

  return {
    title: typeof record.title === 'string' && record.title ? record.title : fallback.title,
    subtitle:
      typeof record.subtitle === 'string' && record.subtitle ? record.subtitle : fallback.subtitle,
    searchPlaceholder: cleanPlaceholder,
    warna1: typeof record.warna1 === 'string' ? record.warna1 : fallback.warna1,
    warna2: typeof record.warna2 === 'string' ? record.warna2 : fallback.warna2,
    bannerAutoSlideInterval:
      Number.isFinite(intervalNum) && intervalNum >= 2
        ? intervalNum
        : fallback.bannerAutoSlideInterval || 4,
    banners: resolvedBanners,
    logoUrl: resolvedLogoUrl,
    logoText:
      typeof record.logoText === 'string' ? record.logoText : fallback.logoText ?? 'BTB',
    watermarkEnabled,
    watermarkText,
    watermarkLink,
  };
};

/**
 * Packs SiteSettings for saving to Google Apps Script so watermark & banner fitMode persist
 * in Google Sheets immediately even if the user has not re-deployed Code.gs yet.
 */
export const packSettingsForCloud = (settings: SiteSettings): SiteSettings => {
  const cleanPlaceholder = stripSearchPlaceholderMeta(settings.searchPlaceholder);
  const meta: PackedUiMeta = {
    we: settings.watermarkEnabled !== false,
    wt: settings.watermarkText ?? '',
    wl: settings.watermarkLink ?? '',
    bf: (settings.banners || []).map((b) => (b.fitMode === 'cover' ? 'cover' : 'contain')),
  };

  return {
    ...settings,
    searchPlaceholder: `${cleanPlaceholder}${META_DELIMITER}${JSON.stringify(meta)}`,
    watermarkEnabled: settings.watermarkEnabled !== false,
    watermarkText: settings.watermarkText ?? '',
    watermarkLink: settings.watermarkLink ?? '',
  };
};
